# 방화벽 규칙 구성
netsh advfirewall firewall add rule name="http" dir=in action=allow protocol=TCP localport=80

# IIS 기능 설치
Install-WindowsFeature Web-Server -IncludeManagementTools

# index.html 파일 복사
Invoke-WebRequest 'https://raw.githubusercontent.com/LODSContent/ChallengeLabs_ArmResources/master/Labs/AIS/index.html' -OutFile 'C:\inetpub\wwwroot\index.html'